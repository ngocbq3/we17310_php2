<?php include "header.php" ?>
<article>
    <h1>CONTACT PAGE</h1>
</article>
<?php include "footer.php" ?>