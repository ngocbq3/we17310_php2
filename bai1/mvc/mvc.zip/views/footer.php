<hr>
<footer>
    Copyright &copy; Company ABC
</footer>
</body>

</html>