<?php include "header.php" ?>
<article>
    <h1>ABOUT PAGE</h1>
</article>
<?php include "footer.php" ?>