<?php include "header.php" ?>
<article>
    <h1>HOME PAGE</h1>
</article>
<?php include "footer.php" ?>