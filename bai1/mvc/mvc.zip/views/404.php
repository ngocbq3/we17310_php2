<?php include "header.php" ?>
<article>
    <h1>404 FILE NOT FOUND!@!</h1>
</article>
<?php include "footer.php" ?>