<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <header>
        <nav>
            <a href="index.php">Home</a> |
            <a href="?ctr=about">About</a> |
            <a href="?ctr=contact">Contact</a> |
            <a href="?ctr=product">Product</a>
        </nav>
    </header>